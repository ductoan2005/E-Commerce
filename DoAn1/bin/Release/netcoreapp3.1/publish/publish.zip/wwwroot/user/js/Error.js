﻿//Alert
$(function () {
    $('#alertBox').removeClass('hide');
    $('#alertBox').delay(2000).slideUp(500);
});